java -jar SAM.jar
